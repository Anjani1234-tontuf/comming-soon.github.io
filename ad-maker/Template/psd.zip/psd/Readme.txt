-This is only for posts with multiple sizes and prices
-The design will look diffrent from single posts so if possible when posting 
keep the products with multiple sizes all together in one post so it lookes unified
